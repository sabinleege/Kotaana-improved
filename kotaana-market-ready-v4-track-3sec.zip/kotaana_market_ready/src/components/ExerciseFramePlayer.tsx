"use client";

/**
 * ExerciseFramePlayer
 * Cycles bryllim-style start / mid / end SVG (or image) frames
 * so multi-frame exercises look animated — same visual role as a GIF.
 *
 * Usage:
 *   <ExerciseFramePlayer
 *     frames={{ start: url1, mid: url2, end: url3 }}
 *     alt="Pull-Up"
 *     className="w-48 h-48"
 *   />
 *
 * Also accepts a plain gif URL — if `gif` is provided it is preferred.
 */

import { useEffect, useState, useCallback } from "react";
import { cn } from "@/lib/utils"; // kotaana already has this (clsx + tailwind-merge)

export type FrameSet = {
  start?: string | null;
  mid?: string | null;
  end?: string | null;
};

type Props = {
  /** Prefer a real GIF when available (hasaneyldrm / mohamedatef) */
  gif?: string | null;
  /** bryllim 3-frame set (or any ordered stills) */
  frames?: FrameSet | null;
  /** Fallback single still */
  image?: string | null;
  alt?: string;
  /** Time each frame is shown (ms). Default 700 */
  intervalMs?: number;
  /** Pause on hover */
  pauseOnHover?: boolean;
  className?: string;
  imgClassName?: string;
};

function collectFrames(frames?: FrameSet | null, image?: string | null): string[] {
  if (!frames && !image) return [];
  const list: string[] = [];
  if (frames?.start) list.push(frames.start);
  if (frames?.mid) list.push(frames.mid);
  if (frames?.end) list.push(frames.end);
  // de-dupe while preserving order
  const seen = new Set<string>();
  const unique = list.filter((u) => {
    if (!u || seen.has(u)) return false;
    seen.add(u);
    return true;
  });
  if (unique.length) return unique;
  if (image) return [image];
  return [];
}

/** Parse [frames] note that seed-extra-libraries stores in instructions */
export function parseFramesFromInstructions(instructions?: string | null): FrameSet | null {
  if (!instructions) return null;
  const m = instructions.match(
    /\[frames\]\s*start=(\S*)\s*mid=(\S*)\s*end=(\S*)/
  );
  if (!m) return null;
  return {
    start: m[1] || null,
    mid: m[2] || null,
    end: m[3] || null,
  };
}

export function ExerciseFramePlayer({
  gif,
  frames,
  image,
  alt = "Exercise demo",
  intervalMs = 700,
  pauseOnHover = true,
  className,
  imgClassName,
}: Props) {
  // Real GIF wins
  if (gif) {
    return (
      <div className={cn("relative overflow-hidden rounded-lg bg-muted", className)}>
        <img
          src={gif}
          alt={alt}
          className={cn("h-full w-full object-contain", imgClassName)}
          loading="lazy"
        />
      </div>
    );
  }

  const sequence = collectFrames(frames, image);
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);

  const tick = useCallback(() => {
    if (sequence.length <= 1) return;
    setIndex((i) => (i + 1) % sequence.length);
  }, [sequence.length]);

  useEffect(() => {
    if (paused || sequence.length <= 1) return;
    const id = setInterval(tick, intervalMs);
    return () => clearInterval(id);
  }, [paused, tick, intervalMs, sequence.length]);

  if (sequence.length === 0) {
    return (
      <div
        className={cn(
          "flex items-center justify-center rounded-lg bg-muted text-muted-foreground text-sm",
          className
        )}
      >
        No animation available
      </div>
    );
  }

  // Single still — no animation needed
  if (sequence.length === 1) {
    return (
      <div className={cn("relative overflow-hidden rounded-lg bg-muted", className)}>
        <img
          src={sequence[0]}
          alt={alt}
          className={cn("h-full w-full object-contain", imgClassName)}
          loading="lazy"
        />
      </div>
    );
  }

  return (
    <div
      className={cn("relative overflow-hidden rounded-lg bg-muted", className)}
      onMouseEnter={() => pauseOnHover && setPaused(true)}
      onMouseLeave={() => pauseOnHover && setPaused(false)}
      role="img"
      aria-label={alt}
    >
      {/* Preload all frames; only the active one is visible */}
      {sequence.map((src, i) => (
        <img
          key={src}
          src={src}
          alt=""
          aria-hidden={i !== index}
          className={cn(
            "absolute inset-0 h-full w-full object-contain transition-opacity duration-200",
            i === index ? "opacity-100" : "opacity-0",
            imgClassName
          )}
          loading={i === 0 ? "eager" : "lazy"}
        />
      ))}

      {/* Frame dots */}
      <div className="absolute bottom-1.5 left-1/2 flex -translate-x-1/2 gap-1">
        {sequence.map((_, i) => (
          <span
            key={i}
            className={cn(
              "h-1.5 w-1.5 rounded-full transition-colors",
              i === index ? "bg-primary" : "bg-primary/30"
            )}
          />
        ))}
      </div>
    </div>
  );
}

export default ExerciseFramePlayer;
