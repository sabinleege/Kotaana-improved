import { AppNav } from "./AppNav";
import { TopBar } from "./TopBar";
export function AppPage({children,name}:{children:React.ReactNode,name?:string|null}){return <div className="page"><TopBar name={name}/><main className="mobile" style={{padding:"18px 0 20px"}}>{children}</main><AppNav/></div>}
