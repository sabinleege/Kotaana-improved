"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";

const items=[
 {href:"/app",label:"Dashboard",icon:"⌂"},{href:"/app/workout",label:"Workout",icon:"◒"},{href:"/app/nutrition",label:"Nutrition",icon:"◔"},{href:"/app/health",label:"Health",icon:"♥"},{href:"/app/progress",label:"Progress",icon:"↗"},{href:"/app/track",label:"Track Me",icon:"⌖"}
];
export function AppNav(){const path=usePathname(); return <nav className="bottom"><div className="bottomin">{items.map(i=>{const active=path===i.href || (i.href!=="/app"&&path.startsWith(i.href));return <Link key={i.href} href={i.href} className={active?"active":""}><span className="icon">{i.icon}</span>{i.label}</Link>})}</div></nav>}
