import Link from "next/link";
import { Logo } from "./Logo";
export function TopBar({name}:{name?:string|null}){return <header className="nav"><div className="container navin"><Logo/><div className="row"><span className="small muted">{name||""}</span><Link className="btn secondary small" href="/app/settings">Settings</Link><Link className="btn secondary small" href="/api/auth/signout">Sign out</Link></div></div></header>}
