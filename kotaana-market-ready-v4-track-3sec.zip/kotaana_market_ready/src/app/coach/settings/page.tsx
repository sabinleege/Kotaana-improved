import { requireRole } from "@/lib/auth/guard";
import { prisma } from "@/lib/db/prisma";
import CoachMomo from "@/components/CoachMomo";
export default async function CoachSettings(){const s=await requireRole('coach');const p=await prisma.profile.findUnique({where:{userId:s.user.id}});return <div className="page"><div className="mobile" style={{padding:'25px 0'}}><CoachMomo initial={{number:p?.momoNumber||'',name:p?.momoName||''}}/></div></div>}
