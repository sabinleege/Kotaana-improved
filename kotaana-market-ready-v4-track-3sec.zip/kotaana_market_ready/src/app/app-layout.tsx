import { requireRole } from "@/lib/auth/guard";
import { prisma } from "@/lib/db/prisma";
import { AppPage } from "@/components/Page";
export async function AthleteFrame({children}:{children:React.ReactNode}){const s=await requireRole("athlete");const p=await prisma.profile.findUnique({where:{userId:s.user.id},select:{fullName:true}});return <AppPage name={p?.fullName||s.user.name}>{children}</AppPage>}
