import { AthleteFrame } from "@/app/app-layout";
import CoachFinder from "@/components/CoachFinder";
export default function AthleteCoach(){return <AthleteFrame><CoachFinder/></AthleteFrame>}
